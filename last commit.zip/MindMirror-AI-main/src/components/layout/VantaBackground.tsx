import React, { useState, useEffect, useRef, ReactNode } from 'react';
import WAVES from 'vanta/dist/vanta.waves.min';
import * as THREE from 'three';

interface VantaBackgroundProps {
  children?: ReactNode;
}

const VantaBackground: React.FC<VantaBackgroundProps> = ({ children }) => {
  const vantaRef = useRef<HTMLDivElement>(null);
  const [vantaEffect, setVantaEffect] = useState<any>(null);

  useEffect(() => {
    if (!vantaEffect) {
      setVantaEffect(
        WAVES({
          el: vantaRef.current,
          THREE: THREE,
          mouseControls: true,
          touchControls: true,
          gyroControls: false,
          minHeight: 200.0,
          minWidth: 200.0,
          scale: 1.0,
          scaleMobile: 1.0,
          color: 0x0, // Black
          shininess: 15.0,
          waveHeight: 15.0,
          waveSpeed: 0.75,
          zoom: 0.75,
        })
      );
    }
    return () => {
      if (vantaEffect && typeof vantaEffect.destroy === 'function') {
        vantaEffect.destroy();
      }
    };
  }, [vantaEffect]);

  return (
    <div ref={vantaRef} style={{ width: '100%', height: '100vh', position: 'relative' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 1 }}>
        {children}
      </div>
    </div>
  );
};

export default VantaBackground;
