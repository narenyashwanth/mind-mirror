import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import MetricsSection from '../components/MetricsSection';
import ConditionRiskFlags from '../components/ConditionRiskFlags';
import PerformanceTrends from '../components/PerformanceTrends';
import DetailedInsights from '../components/DetailedInsights';
import Disclaimer from '../components/Disclaimer';

const ReportPage = () => {
  const navigate = useNavigate();
  const [stressLevel] = useState<'low' | 'moderate' | 'high'>('moderate'); // Demo data

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.2,
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-slate-900 to-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/10 via-cyan-900/10 to-pink-900/10"></div>
        <motion.div 
          className="absolute top-20 left-20 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div 
          className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"
          animate={{
            scale: [1.1, 1, 1.1],
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Content */}
      <motion.div 
        className="relative z-10 max-w-7xl mx-auto px-4 py-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <Header onBack={() => navigate('/')} />
        <MetricsSection stressLevel={stressLevel} />
        <ConditionRiskFlags />
        <PerformanceTrends />
        <DetailedInsights />
        <Disclaimer />
      </motion.div>
    </div>
  );
};

export default ReportPage;